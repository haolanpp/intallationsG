$(function(){
	let player = new Player({
		"id": "mse1",
		"playsinline": false,
		"whitelist": [
				""
		],
		"width": null,
		"height": null,
		"url": "./src/下载.mp4",
		"poster":"./src/b2.jpeg"
      });
	  let player_p = new Player({
		"id": "mss",
		"playsinline": false,
		"whitelist": [
				""
		],
		"width": null,
		"height": null,
		"url": "./src/b1_1.mp4",
		"poster":"./src/b1.jpeg"
      });
	  let player_a = new Player({
		"id": "mss_a",
		"playsinline": false,
		"whitelist": [
				""
		],
		"width": null,
		"height": null,
		"url": "./src/mp4.8.mp4",
		"poster":"./src/b7.jpeg"
      });
	 
	  let player_s = new Player({
		"id": "mss_s",
		"playsinline": false,
		"whitelist": [
				""
		],
		"width": null,
		"height": null,
		"url": "./src/下载 (1).mp5.mp4",
		"poster":"./src/b4.jpeg"
      });
	  let player_d = new Player({
		"id": "mss_d",
		"playsinline": false,
		"whitelist": [
				""
		],
		"width": null,
		"height": null,
		"url": "./src/mp4.6.mp4",
		"poster":"./src/b5.jpeg"
      });
	  let player_f = new Player({
		"id": "mss_f",
		"playsinline": false,
		"whitelist": [
				""
		],
		"width": null,
		"height": null,
		"url": "./src/mp4.7.mp4",
		"poster":"./src/b6.jpeg"
      });
	  let player_g = new Player({
		"id": "mss_g",
		"playsinline": false,
		"whitelist": [
				""
		],
		"width": null,
		"height": null,
		"url": "./src/b1_1.mp4",
		"poster":"./src/b7.jpeg"
      });
	  let player_h = new Player({
		"id": "mss_h",
		"playsinline": false,
		"whitelist": [
				""
		],
		"width": null,
		"height": null,
		"url": "./src/b1_1.mp4",
		"poster":"./src/b8.jpeg"
      });
	  let player_j = new Player({
		"id": "mss_j",
		"playsinline": false,
		"whitelist": [
				""
		],
		"width": null,
		"height": null,
		"url": "./src/b1_1.mp4",
		"poster":"./src/p9.jpeg"
      });
	  let player_k = new Player({
		"id": "mss_k",
		"playsinline": false,
		"whitelist": [
				""
		],
		"width": null,
		"height": null,
		"url": "./src/b1_1.mp4",
		"poster":"./src/p10.jpeg"
      });
	  let player_l = new Player({
		"id": "mss_l",
		"playsinline": false,
		"whitelist": [
				""
		],
		"width": null,
		"height": null,
		"url": "./src/b1_1.mp4",
		"poster":"./src/p11.jpeg"
      });
	  let player_z = new Player({
		"id": "mss_z",
		"playsinline": false,
		"whitelist": [
				""
		],
		"width": null,
		"height": null,
		"url": "./src/b1_1.mp4",
		"poster":"./src/p12.jpeg"
      });
	  let player_x = new Player({
		"id": "mss_x",
		"playsinline": false,
		"whitelist": [
				""
		],
		"width": null,
		"height": null,
		"url": "./src/b1_1.mp4",
		"poster":"./src/p13.jpeg"
      });
	  let player_c = new Player({
		"id": "mss_c",
		"playsinline": false,
		"whitelist": [
				""
		],
		"width": null,
		"height": null,
		"url": "./src/b1_1.mp4",
		"poster":"./src/p14.jpeg"
      });
	  let player_v = new Player({
		"id": "mss_v",
		"playsinline": false,
		"whitelist": [
				""
		],
		"width": null,
		"height": null,
		"url": "./src/b1_1.mp4",
		"poster":"./src/b3.jpeg"
      });
	  let player_b = new Player({
		"id": "mss_b",
		"playsinline": false,
		"whitelist": [
				""
		],
		"width": null,
		"height": null,
		"url": "./src/b1_1.mp4",
		"poster":"./src/p15.jpeg"
      });
	  let player_n = new Player({
		"id": "mss_n",
		"playsinline": false,
		"whitelist": [
				""
		],
		"width": null,
		"height": null,
		"url": "./src/b1_1.mp4",
		"poster":"./src/p16.jpeg"
      });
	  
	  let player_m = new Player({
		"id": "mss_m",
		"playsinline": false,
		"whitelist": [
				""
		],
		"width": null,
		"height": null,
		"url": "./src/b1_1.mp4",
		"poster":"./src/p17.jpeg"
      });
	  let player_q = new Player({
		"id": "mss_q",
		"playsinline": false,
		"whitelist": [
				""
		],
		"width": null,
		"height": null,
		"url": "./src/b1_1.mp4",
		"poster":"./src/p18.jpeg"
      });
	  let player_qw = new Player({
		"id": "mss_lqw",
		"playsinline": false,
		"whitelist": [
				""
		],
		"width": null,
		"height": null,
		"url": "./src/b1_1.mp4",
		"poster":"./src/p19.jpeg"
      });
	  let player_qe= new Player({
		"id": "mss_qe",
		"playsinline": false,
		"whitelist": [
				""
		],
		"width": null,
		"height": null,
		"url": "./src/b1_1.mp4",
		"poster":"./src/p20.jpeg"
      });
})
